package dao;

import java.math.BigDecimal;
import java.sql.*;

public class ProductDAO {

    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/radialsuper?useUnicode=true&characterEncoding=utf8";
        String user = "radialapp";
        String password = "r@dialsuper123";
        return DriverManager.getConnection(url, user, password);
    }

    
    public boolean updateProductDetails(int productId, String productName, int categoryId, int brandId, 
                                         int sizeId, BigDecimal price, String barcode, String unit) {
        String sql = "UPDATE Products SET ProductName=?, CategoryID=?, BrandID=?, SizeID=?, Price=?, Barcode=?, Unit=? WHERE ProductID=?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, productName);
            stmt.setInt(2, categoryId);
            stmt.setInt(3, brandId);
            stmt.setInt(4, sizeId);
            stmt.setBigDecimal(5, price);
            stmt.setString(6, barcode);
            stmt.setString(7, unit);
            stmt.setInt(8, productId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean updateStock(int productId, BigDecimal quantityToAdd) {
        String sql = "UPDATE Products SET Stock = Stock + ? WHERE ProductID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBigDecimal(1, quantityToAdd);  
            stmt.setInt(2, productId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
}