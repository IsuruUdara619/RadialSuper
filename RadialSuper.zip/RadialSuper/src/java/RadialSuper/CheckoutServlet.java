package RadialSuper;

import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String paymentMethod = request.getParameter("paymentMethod");
        String username = (String) session.getAttribute("username");
        double paidAmount = Double.parseDouble(request.getParameter("paidAmount"));
        double amount = Double.parseDouble(request.getParameter("amount")); 
        
        List<Map<String, Object>> saleItems = (List<Map<String, Object>>) session.getAttribute("saleItems");

        if (saleItems == null || saleItems.isEmpty()) {
            session.setAttribute("error", "Cart is empty.");
            response.sendRedirect("sales.jsp");
            return;
        }

        Connection con = null;
        PreparedStatement getUser = null;
        PreparedStatement insert = null;
        PreparedStatement updateStock = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123");
            con.setAutoCommit(false); 

            
            getUser = con.prepareStatement("SELECT Id FROM users WHERE username = ?");
            getUser.setString(1, username);
            ResultSet rs = getUser.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("Id");

               
                insert = con.prepareStatement(
                    "INSERT INTO transactions (amount, payment_method, user_id) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS
                );
                insert.setDouble(1, amount); 
                insert.setString(2, paymentMethod);
                insert.setInt(3, userId);
                insert.executeUpdate();

                ResultSet keys = insert.getGeneratedKeys();
                int transactionId = 0;
                if (keys.next()) {
                    transactionId = keys.getInt(1);

                    
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                    String invoiceNumber = sdf.format(new Date()) + transactionId;

                    session.setAttribute("currentInvoiceNumber", invoiceNumber);
                    session.setAttribute("customTransactionId", invoiceNumber);

                    session.setAttribute("printDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                    session.setAttribute("printInvoice", invoiceNumber);
                    session.setAttribute("printCashier", username);
                    session.setAttribute("printPaymentMethod", paymentMethod);
                }
                keys.close();

                
                String updateSQL = "UPDATE Products SET Stock = Stock - ? WHERE Barcode = ? AND Stock >= ?";
                updateStock = con.prepareStatement(updateSQL);

                for (Map<String, Object> item : saleItems) {
                    double quantity = ((Number) item.get("Quantity")).doubleValue();
                    String barcode = (String) item.get("barcode");

                    updateStock.setDouble(1, quantity);
                    updateStock.setString(2, barcode);
                    updateStock.setDouble(3, quantity);

                    int updated = updateStock.executeUpdate();
                    if (updated == 0) {
                        con.rollback();
                        session.setAttribute("error", "Not enough stock for product: " + barcode);
                        response.sendRedirect("sales.jsp");
                        return;
                    }
                }
            }
            rs.close();

            con.commit(); 

            
            double subtotal = 0;
            for (Map<String, Object> item : saleItems) {
                double price = ((Number) item.get("Price")).doubleValue();
                double qty = ((Number) item.get("Quantity")).doubleValue();
                subtotal += price * qty;
            }
            session.setAttribute("printSubtotal", subtotal);

            double discountPercent = session.getAttribute("discount") != null
                    ? ((Number) session.getAttribute("discount")).doubleValue()
                    : 0;

            double discountAmount = subtotal * (discountPercent / 100.0);
            double total = subtotal - discountAmount;

            session.setAttribute("printDiscountPercent", discountPercent);
            session.setAttribute("printDiscountAmount", discountAmount);
            session.setAttribute("printTotal", total);
            session.setAttribute("printPaidAmount", paidAmount); 
            session.setAttribute("printChange", paidAmount - total); 

            session.setAttribute("printItems", saleItems);
           double totalQuantity = 0.0;
for (Map<String, Object> item : saleItems) {
    Number quantity = (Number) item.get("Quantity");
    totalQuantity += quantity.doubleValue();
}
session.setAttribute("printTotalItems", totalQuantity);
session.setAttribute("printItemTypes", saleItems.size());
                 session.setAttribute("printItemTypes", saleItems.size());

            
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection insertCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123");
                PreparedStatement invoiceInsert = null;
                PreparedStatement invoiceItemInsert = null;

                String invoiceSQL = "INSERT INTO invoices (InvoiceNumber, InvoiceDate, CashierName, PaymentMethod, Subtotal, DiscountPercent, DiscountAmount, Total, PaidAmount, ChangeAmount) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)";
                invoiceInsert = insertCon.prepareStatement(invoiceSQL);
                invoiceInsert.setString(1, (String) session.getAttribute("printInvoice"));
                invoiceInsert.setString(2, (String) session.getAttribute("printCashier"));
                invoiceInsert.setString(3, (String) session.getAttribute("printPaymentMethod"));
                invoiceInsert.setDouble(4, Double.parseDouble(session.getAttribute("printSubtotal").toString()));
                invoiceInsert.setDouble(5, Double.parseDouble(session.getAttribute("printDiscountPercent").toString()));
                invoiceInsert.setDouble(6, Double.parseDouble(session.getAttribute("printDiscountAmount").toString()));
                invoiceInsert.setDouble(7, Double.parseDouble(session.getAttribute("printTotal").toString()));
                invoiceInsert.setDouble(8, Double.parseDouble(session.getAttribute("printPaidAmount").toString())); // ✅
                invoiceInsert.setDouble(9, Double.parseDouble(session.getAttribute("printChange").toString()));     // ✅
                invoiceInsert.executeUpdate();

                String itemSQL = "INSERT INTO invoiceitems (InvoiceNumber, ProductName, Quantity, UnitPrice) VALUES (?, ?, ?, ?)";
                invoiceItemInsert = insertCon.prepareStatement(itemSQL);
                String invoiceNum = (String) session.getAttribute("printInvoice");
                List<Map<String, Object>> items = (List<Map<String, Object>>) session.getAttribute("printItems");

                for (Map<String, Object> item : items) {
                    invoiceItemInsert.setString(1, invoiceNum);
                    invoiceItemInsert.setString(2, (String) item.get("ProductName"));
                    invoiceItemInsert.setDouble(3, ((Number) item.get("Quantity")).doubleValue());
                    invoiceItemInsert.setDouble(4, ((Number) item.get("Price")).doubleValue());
                    invoiceItemInsert.addBatch();
                }
                invoiceItemInsert.executeBatch();

                invoiceInsert.close();
                invoiceItemInsert.close();
                insertCon.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            session.removeAttribute("saleItems");
            session.removeAttribute("discount");

            response.sendRedirect("payment.jsp?success=true&newTransaction=true");

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (con != null) con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            session.setAttribute("error", "Checkout failed: " + e.getMessage());
            response.sendRedirect("sales.jsp");
        } finally {
            try {
                if (updateStock != null) updateStock.close();
                if (insert != null) insert.close();
                if (getUser != null) getUser.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
