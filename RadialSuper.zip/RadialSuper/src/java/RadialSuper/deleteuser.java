package RadialSuper;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/deleteuser")
public class deleteuser extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String password = request.getParameter("password"); 
        String id = request.getParameter("id"); 

        final String ADMIN_PASSWORD = "Sasmitha#828"; 

        if (password == null || !password.equals(ADMIN_PASSWORD)) {
            response.sendRedirect("user.jsp?msg=" + java.net.URLEncoder.encode("Enter valid admin password", "UTF-8"));
            return;
        }

        if (id == null || id.trim().isEmpty()) {
            response.sendRedirect("user.jsp?msg=" + java.net.URLEncoder.encode("Delete failed: Missing user ID", "UTF-8"));
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123");

            PreparedStatement checkStmt = con.prepareStatement("SELECT Username FROM users WHERE Id = ?");
            checkStmt.setInt(1, Integer.parseInt(id));
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getString("Username").equalsIgnoreCase("Sasmitha")) {
                response.sendRedirect("user.jsp?msg=" + java.net.URLEncoder.encode("Delete failed: Cannot delete admin user", "UTF-8"));
            } else {
                PreparedStatement deleteStmt = con.prepareStatement("DELETE FROM users WHERE Id = ?");
                deleteStmt.setInt(1, Integer.parseInt(id));
                int rows = deleteStmt.executeUpdate();

                String msg = (rows > 0) ? "User deleted successfully" : "Delete failed: User not found";
                response.sendRedirect("index.html?msg=" + java.net.URLEncoder.encode(msg, "UTF-8"));
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("user.jsp?msg=" + java.net.URLEncoder.encode("Error: " + e.getMessage(), "UTF-8"));
        }
    }
}
