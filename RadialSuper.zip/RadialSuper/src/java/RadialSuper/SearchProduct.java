package RadialSuper;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "SearchProduct", urlPatterns = {"/SearchProduct"})
public class SearchProduct extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");

        PrintWriter out = response.getWriter();

        String productId = request.getParameter("productId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/radialsuper?useUnicode=true&characterEncoding=UTF-8";
            Connection con = DriverManager.getConnection(url, "radialapp", "r@dialsuper123");
            Statement st = con.createStatement();

            String sql = "SELECT * FROM Products WHERE ProductID = " + productId;
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                String name = rs.getString("ProductName");
                String category = rs.getString("CategoryID");
                String brand = rs.getString("BrandID");
                String size = rs.getString("SizeID");
                String price = rs.getString("Price");
                String stock = rs.getString("Stock");
                String barcode = rs.getString("Barcode");
                String unit = rs.getString("Unit");  

                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Product Details</title>");
                out.println("<style>");
                out.println("body { font-family: 'Segoe UI', sans-serif; background-color: #f4f6f9; margin: 0; padding: 0; }");
                out.println("h2 { text-align: center; color: #333; margin-top: 50px; }");
                out.println("table { width: 80%; margin: 30px auto; border-collapse: collapse; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }");
                out.println("th, td { padding: 15px; text-align: center; border-bottom: 1px solid #ddd; font-size: 16px; color: #333; }");
                out.println("th { background-color: #007bff; color: white; }");
                out.println("tr:hover { background-color: #f1f1f1; }");
                out.println(".btn { display: inline-block; padding: 10px 20px; margin: 20px auto 0; background-color: #28a745; color: white; text-decoration: none; border-radius: 5px; font-size: 14px; text-align: center; cursor: pointer; transition: background-color 0.3s ease; }");
                out.println(".btn:hover { background-color: #218838; }");
                out.println(".container { width: 90%; margin: 0 auto; padding: 30px 0; text-align: center; }");
                out.println(".product-table { width: 100%; border-radius: 10px; overflow: hidden; border-collapse: collapse; }");
                out.println("@media (max-width: 768px) {");
                out.println("body { font-size: 14px; padding: 20px; }");
                out.println("table { width: 100%; }");
                out.println("th, td { font-size: 14px; padding: 12px; }");
                out.println(".btn { font-size: 12px; padding: 8px 16px; }");
                out.println("}");  
                out.println("</style>");
                out.println("</head>");
                out.println("<body>");

                out.println("<div class='container'>");
                out.println("<h2>Product Details</h2>");
                out.println("<table class='product-table'>");
                out.println("<tr>");
                out.println("<th>Product ID</th>");
                out.println("<th>Name</th>");
                out.println("<th>Category ID</th>");
                out.println("<th>Brand ID</th>");
                out.println("<th>Size ID</th>");
                out.println("<th>Price</th>");
                out.println("<th>Stock</th>");
                out.println("<th>Barcode</th>");
                out.println("<th>Unit</th>");  
                out.println("</tr>");

                out.println("<tr>");
                out.println("<td>" + productId + "</td>");
                out.println("<td>" + name + "</td>");
                out.println("<td>" + category + "</td>");
                out.println("<td>" + brand + "</td>");
                out.println("<td>" + size + "</td>");
                out.println("<td>Rs. " + price + "</td>");
                out.println("<td>" + stock + "</td>");
                out.println("<td>" + barcode + "</td>");
                out.println("<td>" + unit + "</td>");  
                out.println("</tr>");
                out.println("</table>");

                out.println("<a href='inventory.jsp' class='btn'>Back to Inventory</a>");
                out.println("</div>");

                out.println("</body>");
                out.println("</html>");
            } else {
                out.println("<script>alert('Product not found!'); window.history.back();</script>");
            }

            rs.close();
            st.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            out.println("<script>alert('Error: " + ex.getMessage() + "');</script>");
        }
    }

    @Override
    public String getServletInfo() {
        return "SearchProduct Servlet";
    }
}
