package RadialSuper;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PurchaseServlet")
public class PurchaseServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/radialsuper";
    private static final String DB_USER = "radialapp";
    private static final String DB_PASSWORD = "r@dialsuper123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String description = request.getParameter("description");
        String invoice = request.getParameter("invoice");
        String amountStr = request.getParameter("amount");

        try {
            double amount = Double.parseDouble(amountStr);
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());

            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String sql = "INSERT INTO records (description, invoice_number, amount, date_time) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, description);
                    stmt.setString(2, invoice);
                    stmt.setDouble(3, amount);
                    stmt.setTimestamp(4, timestamp);
                    stmt.executeUpdate();
                }

                HttpSession session = request.getSession();
                session.setAttribute("msg", "✅ Purchase recorded successfully.");
                response.sendRedirect("dashboard.jsp");
            }

        } catch (NumberFormatException e) {
            HttpSession session = request.getSession();
            session.setAttribute("error", "❌ Invalid amount entered.");
            response.sendRedirect("dashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            HttpSession session = request.getSession();
            session.setAttribute("error", "❌ Error: " + e.getMessage());
            response.sendRedirect("dashboard.jsp");
        }
    }
}
