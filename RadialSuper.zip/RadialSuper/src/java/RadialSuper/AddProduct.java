package RadialSuper;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "AddProduct", urlPatterns = {"/AddProduct"})
public class AddProduct extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 request.setCharacterEncoding("UTF-8");

        String productId = request.getParameter("product_id");
        String productName = request.getParameter("product_name");
        String categoryId = request.getParameter("category_id");
        String brandId = request.getParameter("brand_id");
        String sizeId = request.getParameter("size_id");
        String unitPrice = request.getParameter("unit_price");
        String stock = request.getParameter("stock");
        String barcode = request.getParameter("barcode");
        String unit = request.getParameter("unit"); 

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/radialsuper?useUnicode=true&characterEncoding=utf8";


            con = DriverManager.getConnection(url, "radialapp", "r@dialsuper123");

            
            ps = con.prepareStatement("SELECT * FROM Categories WHERE CategoryID = ?");
            ps.setInt(1, Integer.parseInt(categoryId));
            rs = ps.executeQuery();
            if (!rs.next()) {
                request.setAttribute("errorMessage", "CategoryID does not exist.");
                request.getRequestDispatcher("inventory_add.jsp").forward(request, response);
                return;
            }
            rs.close();
            ps.close();

            
            ps = con.prepareStatement("SELECT * FROM Brands WHERE BrandID = ?");
            ps.setInt(1, Integer.parseInt(brandId));
            rs = ps.executeQuery();
            if (!rs.next()) {
                request.setAttribute("errorMessage", "BrandID does not exist.");
                request.getRequestDispatcher("inventory_add.jsp").forward(request, response);
                return;
            }
            rs.close();
            ps.close();

            
            ps = con.prepareStatement("SELECT * FROM Sizes WHERE SizeID = ?");
            ps.setInt(1, Integer.parseInt(sizeId));
            rs = ps.executeQuery();
            if (!rs.next()) {
                request.setAttribute("errorMessage", "SizeID does not exist.");
                request.getRequestDispatcher("inventory_add.jsp").forward(request, response);
                return;
            }
            rs.close();
            ps.close();

            
            String insertQuery = "INSERT INTO Products (ProductID, ProductName, CategoryID, BrandID, SizeID, Price, Stock, Barcode, Unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(insertQuery);
            ps.setInt(1, Integer.parseInt(productId));
            ps.setString(2, productName);
            ps.setInt(3, Integer.parseInt(categoryId));
            ps.setInt(4, Integer.parseInt(brandId));
            ps.setInt(5, Integer.parseInt(sizeId));
            ps.setBigDecimal(6, new BigDecimal(unitPrice));
            ps.setBigDecimal(7, new BigDecimal(stock)); 
            ps.setString(8, barcode);
            ps.setString(9, unit);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("inventory_add.jsp?success=true");
            } else {
                request.setAttribute("errorMessage", "Failed to add product.");
                request.getRequestDispatcher("inventory_add.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("inventory_add.jsp").forward(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("inventory_add.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Servlet to add new product to inventory.";
    }
}
