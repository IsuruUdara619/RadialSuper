package RadialSuper;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.google.gson.Gson;

@WebServlet("/GetTransactionDetails")
public class GetTransactionDetails extends HttpServlet {
    
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/radialsuper";
    private static final String DB_USER = "radialapp";
    private static final String DB_PASSWORD = "r@dialsuper123";
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        try {
            int transactionId = Integer.parseInt(request.getParameter("transactionId"));
            
            
            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                
                
                Map<String, Object> responseData = new LinkedHashMap<>();
                responseData.put("status", "success");
                
                
                String headerQuery = "SELECT t.amount, t.payment_method, t.cash_paid, " +
                                   "t.transaction_datetime, u.username AS cashier " +
                                   "FROM transactions t JOIN users u ON t.user_id = u.Id " +
                                   "WHERE t.transaction_id = ?";
                
                try (PreparedStatement stmt = con.prepareStatement(headerQuery)) {
                    stmt.setInt(1, transactionId);
                    ResultSet rs = stmt.executeQuery();
                    
                    if (rs.next()) {
                        Map<String, Object> transaction = new LinkedHashMap<>();
                        transaction.put("amount", rs.getDouble("amount"));
                        transaction.put("payment_method", rs.getString("payment_method"));
                        transaction.put("cash_paid", rs.getDouble("cash_paid"));
                        transaction.put("transaction_datetime", rs.getTimestamp("transaction_datetime").toString());
                        transaction.put("cashier", rs.getString("cashier"));
                        responseData.put("transaction", transaction);
                    } else {
                        responseData.put("status", "error");
                        responseData.put("message", "Transaction not found");
                        response.getWriter().write(new Gson().toJson(responseData));
                        return;
                    }
                }
                
                
                String itemsQuery = "SELECT product_name, quantity, unit_price " +
                                   "FROM transaction_items " +
                                   "WHERE transaction_id = ? " +
                                   "ORDER BY item_id";
                
                List<Map<String, Object>> items = new ArrayList<>();
                double subtotal = 0;
                
                try (PreparedStatement stmt = con.prepareStatement(itemsQuery)) {
                    stmt.setInt(1, transactionId);
                    ResultSet rs = stmt.executeQuery();
                    
                    while (rs.next()) {
                        Map<String, Object> item = new LinkedHashMap<>();
                        item.put("product_name", rs.getString("product_name"));
                        item.put("quantity", rs.getDouble("quantity"));
                        item.put("price", rs.getDouble("unit_price"));
                        items.add(item);
                        
                        subtotal += rs.getDouble("unit_price") * rs.getDouble("quantity");
                    }
                }
                
                responseData.put("items", items);
                
                
                Map<String, Object> transaction = (Map<String, Object>) responseData.get("transaction");
                double amount = (Double) transaction.get("amount");
                double discountAmount = subtotal - amount;
                double discountPercent = discountAmount > 0 ? (discountAmount / subtotal * 100) : 0;
                
                transaction.put("subtotal", subtotal);
                transaction.put("discountAmount", discountAmount);
                transaction.put("discountPercent", discountPercent);
                
               
                response.getWriter().write(new Gson().toJson(responseData));
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            Map<String, String> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", "Invalid transaction ID");
            response.getWriter().write(new Gson().toJson(error));
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            Map<String, String> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", "Database error: " + e.getMessage());
            response.getWriter().write(new Gson().toJson(error));
            e.printStackTrace();
        }
    }
}