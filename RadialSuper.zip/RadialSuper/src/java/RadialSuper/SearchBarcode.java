package RadialSuper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/SearchBarcode")
public class SearchBarcode extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

  @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    request.setCharacterEncoding("UTF-8");

    String input = request.getParameter("barcode");

    HttpSession session = request.getSession();
    List<Map<String, Object>> saleItems = (List<Map<String, Object>>) session.getAttribute("saleItems");

    if (saleItems == null) {
        saleItems = new ArrayList<>();
    }

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Products WHERE Barcode = ? OR ProductId = ?")) {

            stmt.setString(1, input);
            stmt.setString(2, input); 

            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) {
                
                request.setAttribute("error", "Product not found for barcode or ID: " + input);
            } else {
                boolean found = false;
                String dbBarcode = rs.getString("Barcode");

                for (Map<String, Object> item : saleItems) {
                    if (item.get("barcode").equals(dbBarcode)) {
                        int qty = (int) item.get("Quantity");
                        item.put("Quantity", qty + 1);
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("barcode", dbBarcode);
                    item.put("ProductName", rs.getString("ProductName"));
                    item.put("Price", rs.getDouble("Price"));
                    item.put("Quantity", 1);
                    item.put("Discount", 0.0); 
                    saleItems.add(item);
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("error", "An error occurred while processing the product.");
    }

    session.setAttribute("saleItems", saleItems);
    request.getRequestDispatcher("sales.jsp").forward(request, response);
}

}
