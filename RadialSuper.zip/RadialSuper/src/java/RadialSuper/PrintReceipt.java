package RadialSuper;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PrintReceipt")
public class PrintReceipt extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String invoiceNumber = request.getParameter("invoice");

        
        Map<String, Object> invoice = new HashMap<>();
        
        List<Map<String, Object>> items = new ArrayList<>();

        try {
           
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123")) {

                
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM invoices WHERE InvoiceNumber = ?");
                stmt.setString(1, invoiceNumber);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    invoice.put("InvoiceNumber", rs.getString("InvoiceNumber"));
                    invoice.put("InvoiceDate", rs.getTimestamp("InvoiceDate"));
                    invoice.put("CashierName", rs.getString("CashierName"));
                    invoice.put("Subtotal", rs.getBigDecimal("Subtotal"));
                    invoice.put("DiscountPercent", rs.getBigDecimal("DiscountPercent"));
                    invoice.put("DiscountAmount", rs.getBigDecimal("DiscountAmount"));
                    invoice.put("Total", rs.getBigDecimal("Total"));
                    invoice.put("PaidAmount", rs.getBigDecimal("PaidAmount"));
                    invoice.put("ChangeAmount", rs.getBigDecimal("ChangeAmount"));
                }

                
                stmt = conn.prepareStatement("SELECT * FROM invoiceitems WHERE InvoiceNumber = ?");
                stmt.setString(1, invoiceNumber);
                rs = stmt.executeQuery();
                while (rs.next()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("ProductName", rs.getString("ProductName"));
                    item.put("Quantity", rs.getBigDecimal("Quantity"));
                    item.put("UnitPrice", rs.getBigDecimal("UnitPrice"));
                    items.add(item);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        request.setAttribute("invoice", invoice);
        request.setAttribute("items", items);
        request.getRequestDispatcher("/receipt.jsp").forward(request, response);
    }
}