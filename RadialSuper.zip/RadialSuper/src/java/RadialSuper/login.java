package RadialSuper;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/radialsuper";
            Connection con = DriverManager.getConnection(url, "radialapp", "r@dialsuper123");
            Statement st = con.createStatement();

            String q1 = "SELECT * FROM users WHERE Username = '" + username + "' AND Password = '" + password + "'";
            ResultSet rs1 = st.executeQuery(q1);

            if (rs1.next()) {
                  request.getSession().setAttribute("username", username);
                
                String updateLogin = "UPDATE users SET last_login = NOW() WHERE Username = '" + username + "'";
                st.executeUpdate(updateLogin);

                
                request.setAttribute("successMessage", "Logging in successfully!");
                response.sendRedirect("dashboard.jsp");

            } else {
               
                request.setAttribute("errorMessage", "Please enter valid username or password.");
                response.sendRedirect("index.html");

            }

        }catch (ClassNotFoundException | SQLException ex) {
    ex.printStackTrace();
    response.getWriter().println("Error: " + ex.getMessage());
}

    }

    @Override
    public String getServletInfo() {
        return "Login Servlet for Radial Super";
    }
}
