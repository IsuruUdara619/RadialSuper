package RadialSuper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/UpdateCart")
public class UpdateCart extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String barcode = request.getParameter("barcode");
        String action = request.getParameter("action");
        String qty = request.getParameter("quantity");
        String discountStr = request.getParameter("discount");

        HttpSession session = request.getSession();
        List<Map<String, Object>> saleItems = (List<Map<String, Object>>) session.getAttribute("saleItems");

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            if (barcode != null && qty != null && !qty.isEmpty()) {
                double requestedQty = Double.parseDouble(qty);

                
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/radialsuper", "radialapp", "r@dialsuper123");

                ps = con.prepareStatement("SELECT Stock FROM Products WHERE Barcode = ?");
                ps.setString(1, barcode);
                rs = ps.executeQuery();

                if (rs.next()) {
                    double stock = rs.getDouble("Stock");

                    if (requestedQty > stock) {
                        request.setAttribute("stockErrorBarcode", barcode);
                        request.setAttribute("stockErrorMessage", "Out of Stock");
                        request.getRequestDispatcher("sales.jsp").forward(request, response);
                        return;
                    }
                }
            }

            if (saleItems != null && barcode != null) {
                Iterator<Map<String, Object>> iterator = saleItems.iterator();

                while (iterator.hasNext()) {
                    Map<String, Object> item = iterator.next();

                    if (barcode.equals(item.get("barcode"))) {
                        if ("remove".equals(action)) {
                            iterator.remove();
                            break;
                        }

                        if (qty != null && !qty.isEmpty()) {
                            try {
                                double quantity = Double.parseDouble(qty);
                                if (quantity >= 0.1) {
                                    item.put("Quantity", quantity);
                                }
                            } catch (NumberFormatException e) {
                                item.put("Quantity", 1.0); 
                            }
                        }

                        break;
                    }
                }
            }

            
            session.setAttribute("saleItems", saleItems);

            
            if (discountStr != null && !discountStr.isEmpty()) {
                try {
                    double discount = Double.parseDouble(discountStr);
                    session.setAttribute("discount", discount);
                } catch (NumberFormatException e) {
                    session.setAttribute("discount", 0.0);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("stockErrorMessage", "Server error: " + e.getMessage());
            request.getRequestDispatcher("sales.jsp").forward(request, response);
            return;
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }

        response.sendRedirect("sales.jsp");
    }
}
