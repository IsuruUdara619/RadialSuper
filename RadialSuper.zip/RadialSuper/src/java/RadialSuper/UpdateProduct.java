package RadialSuper;
import dao.ProductDAO;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet(name = "UpdateProduct", urlPatterns = {"/UpdateProduct"})
public class UpdateProduct extends HttpServlet {
    
   @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
       try {
           Class.forName("com.mysql.cj.jdbc.Driver");
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
       }
                Connection conn = null;
       try {
           conn = DriverManager.getConnection(
                   "jdbc:mysql://localhost:3306/radialsuper?useUnicode=true&characterEncoding=utf8", "radialapp", "r@dialsuper123");
       } catch (SQLException ex) {
           Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
       }

    request.setCharacterEncoding("UTF-8");
    String action = request.getParameter("action");
    String productIdParam = request.getParameter("product_id");

    try {
        if (action != null && productIdParam != null && !productIdParam.trim().isEmpty()) {
            int productId = Integer.parseInt(productIdParam);
            ProductDAO dao = new ProductDAO();

            if ("update".equalsIgnoreCase(action)) {
                String productName = request.getParameter("product_name");
                int categoryId = Integer.parseInt(request.getParameter("category_id"));
                int brandId = Integer.parseInt(request.getParameter("brand_id"));
                int sizeId = Integer.parseInt(request.getParameter("size_id"));
                BigDecimal price = new BigDecimal(request.getParameter("unit_price"));
                String barcode = request.getParameter("barcode");
                String unit = request.getParameter("unit");

                
                boolean productUpdated = dao.updateProductDetails(productId, productName, categoryId, brandId, 
                                                                  sizeId, price, barcode, unit);

                if (productUpdated) {
                    request.setAttribute("message", "Product updated successfully.");
                } else {
                    request.setAttribute("message", "Product update failed.");
                }

                
                BigDecimal newStockQuantity = new BigDecimal(request.getParameter("stock"));

                if (newStockQuantity != null && newStockQuantity.compareTo(BigDecimal.ZERO) > 0) {
                    
                    boolean stockUpdated = dao.updateStock(productId, newStockQuantity);

                    if (stockUpdated) {
                        request.setAttribute("message", "Product stock updated successfully.");
                    } else {
                        request.setAttribute("message", "Stock update failed.");
                    }
                }

            } else if ("delete".equalsIgnoreCase(action)) {
                    String sql = "DELETE FROM Products WHERE ProductID=?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, productId);

                    int deleted = stmt.executeUpdate();
                    request.setAttribute("message", deleted > 0 ? "Product deleted successfully." : "Delete failed.");

                } else {
                request.setAttribute("message", "Invalid action.");
            }

        } else {
            request.setAttribute("message", "Missing Product ID or Action.");
        }
    } catch (Exception e) {
        request.setAttribute("message", "Error: " + e.getMessage());
        e.printStackTrace();
    }

    request.getRequestDispatcher("inventory_update.jsp").forward(request, response);
}
}
